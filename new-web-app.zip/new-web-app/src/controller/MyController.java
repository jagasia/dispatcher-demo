package controller;

public class MyController {
	
	@RequestMapping("/index")
	public String home()
	{
		System.out.println("This is home method in my controller");
		return "index";
	}
	@RequestMapping("/contactus")
	public String contact()
	{
		System.out.println("This is contact us method in my controller");
		return "contactus";
	}
}